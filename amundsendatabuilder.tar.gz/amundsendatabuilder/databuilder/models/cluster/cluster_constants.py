# Copyright Contributors to the Amundsen project.
# SPDX-License-Identifier: Apache-2.0

CLUSTER_NODE_LABEL = 'Cluster'

CLUSTER_RELATION_TYPE = 'CLUSTER'
CLUSTER_REVERSE_RELATION_TYPE = 'CLUSTER_OF'

CLUSTER_NAME_PROP_KEY = 'name'
