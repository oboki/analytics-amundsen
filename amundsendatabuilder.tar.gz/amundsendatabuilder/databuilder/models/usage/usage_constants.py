# Copyright Contributors to the Amundsen project.
# SPDX-License-Identifier: Apache-2.0

READ_RELATION_TYPE = 'READ'
READ_REVERSE_RELATION_TYPE = 'READ_BY'

READ_RELATION_COUNT_PROPERTY = 'read_count'
