# Copyright Contributors to the Amundsen project.
# SPDX-License-Identifier: Apache-2.0

# String for partition column badge
PARTITION_BADGE = 'partition column'
